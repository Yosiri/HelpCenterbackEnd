/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package designingphase.pkg1;

/**
 *
 * @author aldri
 */

public class DesigningPhase1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        LogIn_DesignPhase1 LID = new LogIn_DesignPhase1();
        LID.setVisible(true);
    }
    
}
