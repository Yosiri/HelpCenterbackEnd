/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package designingphase.pkg1;

/**
 *
 * @author aldri
 */
public class UserSession {
    private static String username;
    private static int usersId;
    private static String email;
    
    public static void setUser(String username, int usersId, String email) {
        UserSession.username = username;
        UserSession.usersId = usersId;
        UserSession.email = email;
    }
    
    // Getters
    public static String getUsername() { 
        return username; 
    }
    
    public static int getUsersId() { 
        return usersId; 
    }
    
    public static String getEmail() { 
        return email; 
    }
    
    // Clear session (for logout)
    public static void clear() {
        username = null;
        usersId = 0;
        email = null;
    }
    
    // Check if user is logged in
    public static boolean isLoggedIn() {
        return username != null && usersId > 0;
    }
}
